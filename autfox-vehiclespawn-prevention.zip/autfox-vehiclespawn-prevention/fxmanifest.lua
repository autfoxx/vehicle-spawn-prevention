fx_version 'cerulean'
game 'gta5'

author 'AutFox'
description 'Vehicle Spawn Prevention Script'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
} 