Config = {}
Config.Zones = {
    {
        coords = vector3(0.0, 0.0, 0.0), -- Change these coordinates
        radius = 100.0 -- Change radius in meters
    }
    -- Add more zones as needed following the same format
} 